---
name: "Bug Report"
about: Create a report to help us improve
---

<!--
Thank you for reporting a possible bug in Alibaba Cloud CLI
Please fill in as much of the template below as you can.

Command Format: The Command Format you are working on when bug occurs.
Execution Command: If it is convenient, please provide your real running command.
(Please be careful not to expose sensitive information,like AK.)
Output: Output after running the command.
If crash, please provide the stack trace.

If build error, please provide compiler information: compiler and version, etc
-->

* **Command Format**:

* **Execution Command**:

* **Output**:

<!-- Please provide more details below this comment. -->
