---
name: "Demand Report"
about: Create a demand report to help us improve
---

<!--
Thank you for reporting a demand in Alibaba Cloud CLI
Please fill in as much of the template below as you can.

Type of Demand: The type of your Demand, for example, optimizing the user experience, adding features, and enhancing features.
Detailed Description: Describe your needs in detail
Design: If you have a design, please let us know what you think.
-->

* **Type of Demand**:

* **Detailed Description**:

* **Design**:
