package credentials

type sessionCredential struct {
	AccessKeyId     string
	AccessKeySecret string
	SecurityToken   string
}
